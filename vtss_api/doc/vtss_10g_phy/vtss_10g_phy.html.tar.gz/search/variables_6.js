var searchData=
[
  ['gain',['gain',['../structvtss__phy__10g__ib__conf__t.html#afac1dff6f8593f06f674c01a9e5c5a35',1,'vtss_phy_10g_ib_conf_t']]],
  ['gainadj',['gainadj',['../structvtss__phy__10g__ib__conf__t.html#a6379a18c262a16ce3f98dd7a21039954',1,'vtss_phy_10g_ib_conf_t']]],
  ['generate_5fpause',['generate_pause',['../structvtss__aneg__t.html#a98a2aea7496c0daa6d0dc69abf8301b6',1,'vtss_aneg_t']]],
  ['good_5fcrc',['good_crc',['../structvtss__phy__10g__pkt__mon__conf__t.html#a958255914b494caefe6dcb728dda9942',1,'vtss_phy_10g_pkt_mon_conf_t']]],
  ['group',['group',['../structvtss__debug__info__t.html#a3ae3b878872b3d3333a1bc788bd6f902',1,'vtss_debug_info_t']]]
];
