var searchData=
[
  ['ob_5fconf',['ob_conf',['../structvtss__phy__10g__mode__t.html#a95717c613a0b21dac9b7831737d3bf9f',1,'vtss_phy_10g_mode_t']]],
  ['obey_5fpause',['obey_pause',['../structvtss__aneg__t.html#aec5f64ae1b45f4e5e980d27ab48a4dcd',1,'vtss_aneg_t']]],
  ['offs',['offs',['../structvtss__phy__10g__ib__conf__t.html#a24f42824b52265cb47efada603fc6089',1,'vtss_phy_10g_ib_conf_t']]],
  ['op_5fmode',['op_mode',['../structvtss__phy__10g__apc__conf__t.html#a4bd4900a02febfbfc1f65371e2654889',1,'vtss_phy_10g_apc_conf_t']]],
  ['op_5fmode_5fflag',['op_mode_flag',['../structvtss__phy__10g__apc__conf__t.html#ab9a8e7375b90597ef64fc7a7248b8d00',1,'vtss_phy_10g_apc_conf_t']]],
  ['oper_5fmode',['oper_mode',['../structvtss__phy__10g__mode__t.html#a49ff2f20ea7a24ad1fabb82c27b88248',1,'vtss_phy_10g_mode_t']]],
  ['oper_5fup',['oper_up',['../structport__custom__conf__t.html#ada6ec0f9425ab35571c58fe892712717',1,'port_custom_conf_t']]]
];
