var searchData=
[
  ['n_5febc_5fthr_5fl',['n_ebc_thr_l',['../structvtss__ewis__counter__threshold__s.html#ac8bfccf1dfe4b0bd32eb2b074a48e890',1,'vtss_ewis_counter_threshold_s']]],
  ['n_5febc_5fthr_5fp',['n_ebc_thr_p',['../structvtss__ewis__counter__threshold__s.html#a488f5f0c2c050716b68387cdbe095fd2',1,'vtss_ewis_counter_threshold_s']]],
  ['n_5febc_5fthr_5fs',['n_ebc_thr_s',['../structvtss__ewis__counter__threshold__s.html#a6a30fed093e77d7ae533da5192bbb707',1,'vtss_ewis_counter_threshold_s']]],
  ['nanoseconds',['nanoseconds',['../structvtss__timestamp__t.html#a190b709ec29538405f5d98d842cbe72c',1,'vtss_timestamp_t']]],
  ['network',['network',['../structvtss__ipv4__uc__t.html#a32915a317805269d037e0220d2ecefb9',1,'vtss_ipv4_uc_t::network()'],['../structvtss__ipv6__uc__t.html#a2339571efaadb6706f4a2bbd40b26b19',1,'vtss_ipv6_uc_t::network()']]],
  ['next_5fpage',['next_page',['../structvtss__phy__10g__clause__37__adv__t.html#a3b0e60db8b6f4a54d17167e21c71f5ab',1,'vtss_phy_10g_clause_37_adv_t']]],
  ['no_5fof_5ferrors',['no_of_errors',['../structvtss__phy__10g__prbs__mon__conf__t.html#a1d9eb3fdedc7ec14d5726e78548e8821',1,'vtss_phy_10g_prbs_mon_conf_t']]],
  ['no_5fsync',['no_sync',['../structvtss__phy__10g__prbs__mon__conf__t.html#a5d17118735783b9db1cbfbde3f879c66',1,'vtss_phy_10g_prbs_mon_conf_t']]],
  ['now',['now',['../structvtss__mtimer__t.html#add3b87516e5458ed0e022bedb0e4029d',1,'vtss_mtimer_t']]]
];
