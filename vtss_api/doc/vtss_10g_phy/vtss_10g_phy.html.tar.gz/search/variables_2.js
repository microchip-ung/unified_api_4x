var searchData=
[
  ['c',['c',['../structvtss__phy__10g__ib__conf__t.html#a66cdb42c883bc8b534009d640814a0ea',1,'vtss_phy_10g_ib_conf_t']]],
  ['c_5fctrl',['c_ctrl',['../structvtss__phy__10g__ob__status__t.html#a023275543dfe3b08f950b275c9387a3d',1,'vtss_phy_10g_ob_status_t']]],
  ['c_5fintrpt',['c_intrpt',['../structvtss__gpio__10g__gpio__mode__t.html#af7b7b5b97d5720ff61af1efbdf88a05b',1,'vtss_gpio_10g_gpio_mode_t']]],
  ['cfg0',['cfg0',['../structvtss__phy__10g__mode__t.html#ad33eac5e889b761170ae46c90a149fcf',1,'vtss_phy_10g_mode_t']]],
  ['channel_5fconf',['channel_conf',['../structvtss__phy__10g__init__parm__t.html#a4941b7f495aa6b4a1f1fdef9c905a3c4',1,'vtss_phy_10g_init_parm_t']]],
  ['channel_5fid',['channel_id',['../structvtss__phy__10g__mode__t.html#a1fe5185901a752b2508c37913327aded',1,'vtss_phy_10g_mode_t::channel_id()'],['../structvtss__phy__10g__auto__failover__conf__t.html#a586711e07a21232eaaad062c8ad5933f',1,'vtss_phy_10g_auto_failover_conf_t::channel_id()'],['../structvtss__phy__10g__id__t.html#ab363cd03ba78c8fc7bed2f2c2432c2f7',1,'vtss_phy_10g_id_t::channel_id()']]],
  ['chip_5fno',['chip_no',['../structvtss__debug__info__t.html#ab13fac3e26aaa17fab093e5215c44cd3',1,'vtss_debug_info_t::chip_no()'],['../structvtss__debug__lock__t.html#afb93bec412266f4177d647b67a2becee',1,'vtss_debug_lock_t::chip_no()']]],
  ['ckout_5fsel',['ckout_sel',['../structvtss__phy__10g__ckout__conf__t.html#a1b24185c026734576cd96ceb585fe3ae',1,'vtss_phy_10g_ckout_conf_t']]],
  ['clear',['clear',['../structvtss__debug__info__t.html#a2a140d367ac309ba02799aad29570c1d',1,'vtss_debug_info_t']]],
  ['clk_5fsel_5fno',['clk_sel_no',['../structvtss__phy__10g__line__clk__conf__t.html#a1646ceb97a79a51479c489f53e422dac',1,'vtss_phy_10g_line_clk_conf_t::clk_sel_no()'],['../structvtss__phy__10g__host__clk__conf__t.html#ab0a496b816dcda682299f7ca5af966db',1,'vtss_phy_10g_host_clk_conf_t::clk_sel_no()']]],
  ['complete',['complete',['../structvtss__phy__10g__clause__37__status__t.html#a2a2dbbc167db1d9c80a24de7547366ac',1,'vtss_phy_10g_clause_37_status_t']]],
  ['config_5fbit_5fmask',['config_bit_mask',['../structvtss__phy__10g__ib__conf__t.html#a28abf28daaf4571c068668f197522fa4',1,'vtss_phy_10g_ib_conf_t']]],
  ['copper',['copper',['../structvtss__port__status__t.html#a339748df2f6fd49d2553e094c0331d68',1,'vtss_port_status_t']]],
  ['cs_5fwait_5fns',['cs_wait_ns',['../structvtss__pi__conf__t.html#a14ba80fd6679a6a2b2b0df00533b7c3d',1,'vtss_pi_conf_t']]],
  ['cur_5fversion',['cur_version',['../structvtss__restart__status__t.html#a62459b1e56a15699e0a0577984448c9a',1,'vtss_restart_status_t']]]
];
