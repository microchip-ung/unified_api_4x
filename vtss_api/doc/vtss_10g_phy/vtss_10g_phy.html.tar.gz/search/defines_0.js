var searchData=
[
  ['amplitude_5fpoints',['AMPLITUDE_POINTS',['../vtss__phy__10g__api_8h.html#a4b8a1ae8afda73ad5a2f35da6ce166f2',1,'vtss_phy_10g_api.h']]]
];
