var searchData=
[
  ['llabs',['llabs',['../vtss__os__ecos_8h.html#a129cc3857e8929e43bba7f843c9c8cf8',1,'vtss_os_ecos.h']]]
];
