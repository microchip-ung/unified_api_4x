var searchData=
[
  ['activity',['ACTIVITY',['../vtss__phy__api_8h.html#a99d51cd6d65b753300d97700ed01ac83a995d34bcabbc4f6dd5347f17464c4a2f',1,'vtss_phy_api.h']]],
  ['autonegotiation_5ffault',['AUTONEGOTIATION_FAULT',['../vtss__phy__api_8h.html#a99d51cd6d65b753300d97700ed01ac83afff9c301501fdef941ef70cabc1143d8',1,'vtss_phy_api.h']]]
];
