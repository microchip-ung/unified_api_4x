var searchData=
[
  ['nanoseconds',['nanoseconds',['../structvtss__timestamp__t.html#a190b709ec29538405f5d98d842cbe72c',1,'vtss_timestamp_t']]],
  ['near_5fend_5fenable',['near_end_enable',['../structvtss__phy__loopback__t.html#ad59d114b3b5828abb1064fc224b6384b',1,'vtss_phy_loopback_t']]],
  ['network',['network',['../structvtss__evc__conf__t.html#a4c37d0ccdfcef79253332897d1af4f2c',1,'vtss_evc_conf_t::network()'],['../structvtss__ipv4__uc__t.html#a32915a317805269d037e0220d2ecefb9',1,'vtss_ipv4_uc_t::network()'],['../structvtss__ipv6__uc__t.html#a2339571efaadb6706f4a2bbd40b26b19',1,'vtss_ipv6_uc_t::network()']]],
  ['next',['next',['../structtag__vtss__fdma__list.html#a1036a4dc4dc374fe24e64517b64a134f',1,'tag_vtss_fdma_list']]],
  ['next_5fpage',['next_page',['../structvtss__port__clause__37__adv__t.html#a7eabf63233c89c88783f2c0e9e46e7bd',1,'vtss_port_clause_37_adv_t']]],
  ['nni',['nni',['../structvtss__evc__pb__conf__t.html#aab69357ae9e47f61b5b1930ed1bead22',1,'vtss_evc_pb_conf_t']]],
  ['no_5fwait',['no_wait',['../structvtss__packet__rx__meta__t.html#a7d8b06fbb9ef626d451020505365371f',1,'vtss_packet_rx_meta_t']]],
  ['now',['now',['../structvtss__mtimer__t.html#add3b87516e5458ed0e022bedb0e4029d',1,'vtss_mtimer_t']]],
  ['npi',['npi',['../structvtss__packet__rx__queue__conf__t.html#a9fca10ff5800020d1e2de91e2e859d2a',1,'vtss_packet_rx_queue_conf_t']]],
  ['number',['number',['../structvtss__phy__led__mode__select__t.html#a2653733ad414ecd8589aafb20ec19050',1,'vtss_phy_led_mode_select_t']]]
];
