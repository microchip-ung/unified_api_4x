var searchData=
[
  ['serdes_5ffields_5ft',['serdes_fields_t',['../structserdes__fields__t.html',1,'']]]
];
