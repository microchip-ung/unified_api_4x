var searchData=
[
  ['warm_5fstart_5fenable',['warm_start_enable',['../structvtss__init__conf__t.html#ab2dd9c23fe904633cc6e5dffea5168b1',1,'vtss_init_conf_t']]],
  ['wis',['wis',['../structvtss__phy__10g__serdes__status__t.html#a22a0708a2088cbaa6d37e17de066699b',1,'vtss_phy_10g_serdes_status_t::wis()'],['../structvtss__phy__10g__status__t.html#a1ef85061ee5c4edbc80e535b4016d26b',1,'vtss_phy_10g_status_t::wis()']]],
  ['wol_5fmac',['wol_mac',['../structvtss__phy__wol__conf__t.html#ab68c86b9564d909926d66bd77774e852',1,'vtss_phy_wol_conf_t']]],
  ['wol_5fpass',['wol_pass',['../structvtss__phy__wol__conf__t.html#a961f1da4473e1b44d04b296c57ef2d86',1,'vtss_phy_wol_conf_t']]],
  ['wol_5fpasswd_5flen',['wol_passwd_len',['../structvtss__phy__wol__conf__t.html#a2103d04763116cf8292e2174a6df9ca1',1,'vtss_phy_wol_conf_t']]],
  ['wref_5fclk_5fdiv',['wref_clk_div',['../structvtss__phy__10g__mode__t.html#ad9eac3efb5836cf9d3682aa7d8746680',1,'vtss_phy_10g_mode_t']]],
  ['wrefclk',['wrefclk',['../structvtss__phy__10g__mode__t.html#a168de6bd6c25a2b86506240053d0555d',1,'vtss_phy_10g_mode_t']]]
];
