var searchData=
[
  ['mac_5faddr_5fbroadcast',['MAC_ADDR_BROADCAST',['../types_8h.html#a750ea370493bfd6f3bfe33f51029a1bc',1,'types.h']]],
  ['max_5fcfg_5fbuf_5fsize',['MAX_CFG_BUF_SIZE',['../vtss__phy__api_8h.html#a68a0fea769441ea5cddf0e20dcaa39bf',1,'vtss_phy_api.h']]],
  ['max_5fstat_5fbuf_5fsize',['MAX_STAT_BUF_SIZE',['../vtss__phy__api_8h.html#ac39ba084268b216a32f45ba50fbb7995',1,'vtss_phy_api.h']]],
  ['max_5fwol_5fmac_5faddr_5fsize',['MAX_WOL_MAC_ADDR_SIZE',['../vtss__phy__api_8h.html#a39229a4c50849c42654ac6f16bac36b1',1,'vtss_phy_api.h']]],
  ['max_5fwol_5fpasswd_5fsize',['MAX_WOL_PASSWD_SIZE',['../vtss__phy__api_8h.html#afbc5734476b6e1e9b3ff9a8563d491b5',1,'vtss_phy_api.h']]],
  ['min_5fwol_5fpasswd_5fsize',['MIN_WOL_PASSWD_SIZE',['../vtss__phy__api_8h.html#ada0fbbc3439e5405fea904b1d0c5d0d1',1,'vtss_phy_api.h']]]
];
