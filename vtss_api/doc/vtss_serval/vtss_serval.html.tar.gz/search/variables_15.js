var searchData=
[
  ['warm_5fstart_5fenable',['warm_start_enable',['../structvtss__init__conf__t.html#ab2dd9c23fe904633cc6e5dffea5168b1',1,'vtss_init_conf_t']]],
  ['wol_5fmac',['wol_mac',['../structvtss__phy__wol__conf__t.html#ab68c86b9564d909926d66bd77774e852',1,'vtss_phy_wol_conf_t']]],
  ['wol_5fpass',['wol_pass',['../structvtss__phy__wol__conf__t.html#a961f1da4473e1b44d04b296c57ef2d86',1,'vtss_phy_wol_conf_t']]],
  ['wol_5fpasswd_5flen',['wol_passwd_len',['../structvtss__phy__wol__conf__t.html#a2103d04763116cf8292e2174a6df9ca1',1,'vtss_phy_wol_conf_t']]]
];
