var searchData=
[
  ['zero_5fperiod_5ferr',['zero_period_err',['../structvtss__oam__ccm__status__t.html#a7c1cd84971e80f4f69881e596518ef96',1,'vtss_oam_ccm_status_t']]]
];
