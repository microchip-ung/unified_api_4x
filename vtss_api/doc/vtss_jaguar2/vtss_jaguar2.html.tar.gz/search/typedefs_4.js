var searchData=
[
  ['tod_5fget_5fns_5fcnt_5fcb_5ft',['tod_get_ns_cnt_cb_t',['../vtss__misc__api_8h.html#a0b309ceee2622e71daa3be9e6d679770',1,'vtss_misc_api.h']]]
];
