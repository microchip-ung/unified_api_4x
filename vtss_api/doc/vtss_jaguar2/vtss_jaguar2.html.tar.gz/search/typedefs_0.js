var searchData=
[
  ['bool',['BOOL',['../types_8h.html#a67bb6a3d7ee6a2a5950ce437abbe31c8',1,'types.h']]]
];
