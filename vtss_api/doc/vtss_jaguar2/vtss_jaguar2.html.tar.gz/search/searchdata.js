var indexSectionsWithContent =
{
  0: "abcdefghiklmnopqrstuvwxy",
  1: "ipstv",
  2: "loptv",
  3: "lv",
  4: "abcdefghiklmnopqrstuvwxy",
  5: "bciptuv",
  6: "acdlorv",
  7: "abcdeflrtv",
  8: "abcfmptuv",
  9: "ls"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros",
  9: "Pages"
};

