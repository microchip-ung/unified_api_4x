var searchData=
[
  ['ewis_5fprbs31_5fsat_5ferr',['EWIS_PRBS31_SAT_ERR',['../vtss__wis__api_8h.html#ad95c6db8a24137cf78bbaac5f758e3e6aa64bec345f3b6f7c14cb2e3e9557c645',1,'vtss_wis_api.h']]],
  ['ewis_5fprbs31_5fsingle_5ferr',['EWIS_PRBS31_SINGLE_ERR',['../vtss__wis__api_8h.html#ad95c6db8a24137cf78bbaac5f758e3e6a26f8dc21edf387c086133418227b4c61',1,'vtss_wis_api.h']]]
];
