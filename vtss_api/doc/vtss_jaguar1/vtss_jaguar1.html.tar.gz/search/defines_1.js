var searchData=
[
  ['boolean_5fstorage_5fcount',['BOOLEAN_STORAGE_COUNT',['../vtss__phy__10g__api_8h.html#aa24a15859fc6805d5be20692a9b51fd6',1,'vtss_phy_10g_api.h']]]
];
